var myApp = angular.module('myApp', []);

myApp.controller('MainCtrl', function($scope,$rootScope) {
    $scope.dispThisJobs = function () {
        var newsStr = document.getElementById('seljob').value;
        var newsArr = [];
        newsArr = JSON.parse(newsStr);
        $scope.myjob = newsArr;
    };
});
