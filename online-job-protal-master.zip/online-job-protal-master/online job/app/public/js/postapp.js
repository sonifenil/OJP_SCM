var myApp = angular.module('myApp', []);


myApp.controller('SubCtrl', function($scope,$rootScope) {
    $scope.searchdata=document.getElementById('searchs').value;

});

myApp.controller('MainCtrl', function($scope,$rootScope) {

    $scope.category= [
        {type:'Accounting jobs'},       {type:'Bank jobs'},        {type:'Consultant jobs'},  {type:'Engineering jobs'},
        {type:'Export Import jobs'},    {type:'Security jobs'},    {type:'HR jobs'},          {type:'Hotel jobs'},      {type:'Application Programming jobs'},
        {type:'Client server jobs'},    {type:'DBA jobs'},         {type:'Ecommerce jobs'},   {type:'ERP jobs'},        {type:'VLSI jobs'},
        {type:'Mainframe jobs'},        {type:'Mobile jobs'},      {type:'IT jobs'},          {type:'Testing jobs'},    {type:'System Programming jobs'},
        {type:'Telecom Software jobs'}, {type:'BPO jobs'},         {type:'Legal jobs'},       {type:'Marketing jobs'},  {type:'Packaging jobs'},
        {type:'Maintenance jobs'},      {type:'Sales jobs'},       {type:'Secretary jobs'},   {type:'Corporate Planning jobs'},
        {type:'Site Engineering jobs'}, {type:'Film jobs'},        {type:'Teaching jobs'},    {type:'Airline jobs'},    {type:'Graphic Designer jobs'},
        {type:'Shipping jobs'},         {type:'Analytics jobs'},   {type:'Advertising jobs'}, {type:'Agriculture jobs'},{type:'Animation jobs'},
        {type:'Architecture jobs'},     {type:'Automobile jobs'},  {type:'sanitary jobs'},    {type:'Chemical jobs'},   {type:'Electrical jobs'},
        {type:'Airline jobs'},          {type:'Industrial jobs'},  {type:'Insurance jobs'},   {type:'Media jobs'},      {type:'Medical jobs'},
        {type:'Printing jobs'},         {type:'Publishing jobs'},  {type:'Real Estate jobs'}, {type:'Retail jobs'},     {type:'Shopping jobs'},
        {type:'Textiles jobs'},         {type:'Fitness trainer jobs'},                        {type:'Internet jobs'},
    ];

    $scope.location=[
        {type:'Bangalore'},         {type:'Mumbai'},        {type:'Delhi'},         {type:'Hyderabad'},         {type:'Ahmedabad'},
        {type:'Chennai'},           {type:'Kolkata'},       {type:'Surat'},         {type:'Pune'},              {type:'Jaipure'},
        {type:'Lucknow'},           {type:'Kanpur'},        {type:'Nagpure'},       {type:'Visakhapatnam'},     {type:'Indore'},
        {type:'Thane'},             {type:'Bhopal'},        {type:'Tirupathi'},     {type:'Moradabad'},         {type:'Mysore'},
        {type:'Bareily'},           {type:'Gurgaon'},       {type:'Aligarh'},       {type:'Jalandhar'},         {type:'Salem'},
        {type:'Bhiwandi'},          {type:'Saharanpur'},    {type:'Gorakhpur'},     {type:'Bikaner'},           {type:'Amravati'},
        {type:'Noida'},             {type:'Bhilai'},        {type:'Cuttack'},       {type:'Kochi'},             {type:'Nellore'},
        {type:'Bhavnagar'},         {type:'Dehradun'},      {type:'Durgapur'},      {type:'Asansol'},           {type:'Nanded'},
        {type:'Kolhapur'},          {type:'Ajmer'},         {type:'Akola'},         {type:'Gulbarga'},          {type:'Jamnagar'},
        {type:'Ujjain'},            {type:'Loni'},          {type:'Siliguri'},      {type:'Jhansi'},            {type:'Ulhasnagar'},
        {type:'Jammu'},             {type:'Mangalore'},     {type:'Belgaum'},       {type:'Ambattur'},          {type:'Tirunelveli'},
        {type:'Malegaon'},          {type:'Udaipur'},       {type:'Maheshtala'},    {type:'Davanagere'},        {type:'Kurnool'},
        {type:'Bellary'},           {type:'Patiala'},       {type:'Gopalpur'},      {type:'Panihati'}
    ];

    $scope.add = function(jobs) {
        $scope.jobs.push(angular.copy(jobs));
    };

    $scope.dispData= function() {

        var newsStr=document.getElementById('alljobs').value;
        var newsArr=[];
        var xyz=[];
        newsArr=JSON.parse(newsStr);
        var x=[];
        for(var i=1;i<newsArr.length;i++){
            if(newsArr[i].jobaccept=='true'){
                x.push(newsArr[i]);
            }
        }
        $scope.cat=document.getElementById('searchs').value;
        $scope.jobs=x;

    };

    $scope.dispjob= function() {
        var newsStr=document.getElementById('alljobs').value;
        var newsArr=[];
        newsArr=JSON.parse(newsStr);
        var x=[];
        for(var i=1;i<newsArr.length;i++){
            if(newsArr[i].jobaccept!='true'){
                x.push(newsArr[i]);
            }
        }
        $scope.jobs=x;

    };

    $scope.delNewspaper= function(index) {
        alert($scope.jobs[index].Name);
        //   var np=$scope.jobs[index].Name;
        document.getElementById('newspaperName').value=$scope.jobs[index].Name;
//        $scope.jobs.splice(index,1);
//        document.getElementById('newspaperName').value=np;
    };
    $scope.dispThisJobs = function () {
        var newsStr = document.getElementById('seljob').value;
        var newsArr = [];
        var datas = [];
        newsArr = JSON.parse(newsStr);
        for(var i=1;i<newsArr.length;i++){
            datas.push(newsArr[i]);
        }
        $scope.myjob = datas;
    };
    $scope.dispThatJobs = function () {
        var newsStr = document.getElementById('seljob').value;
        var newsArr = [];
        var datas = [];
        newsArr = JSON.parse(newsStr);
        for(var i=0;i<newsArr.length;i++){
            datas.push(newsArr[i]);
        }
        $scope.myjob = datas;
    };
});

