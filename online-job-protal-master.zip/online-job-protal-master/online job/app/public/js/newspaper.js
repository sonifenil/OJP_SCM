

var myApp = angular.module('myApp', []);

myApp.run(function ($rootScope) {

    $rootScope.Addnewspaper = {Name:'',Size:'',Price:''};

    $rootScope.Addnewspaper = [];

});

myApp.controller('MainCtrl', function($scope,$rootScope) {

    $scope.add = function(Addnewspaper) {
        $scope.Addnewspaper.push(angular.copy(Addnewspaper));
    };

    $scope.dispData= function() {
        var newsStr=document.getElementById('news').value;
        var newsArr=[];
        newsArr=JSON.parse(newsStr);
        $scope.Addnewspaper=newsArr;
    };

    $scope.delNewspaper= function(index) {
        alert($scope.Addnewspaper[index].Name);
        //   var np=$scope.Addnewspaper[index].Name;
        document.getElementById('newspaperName').value=$scope.Addnewspaper[index].Name;
//        $scope.Addnewspaper.splice(index,1);
//        document.getElementById('newspaperName').value=np;
    }

});
