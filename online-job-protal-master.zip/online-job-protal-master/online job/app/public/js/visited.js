var myApp = angular.module('myApp', []);

myApp.controller('MainCtrl', function($scope,$rootScope) {
    $scope.applies=[];

    $scope.dspData = function () {
        var visitors = document.getElementById('visitors').value;
        var loggers = document.getElementById('users').value;
        var pid=parseInt(document.getElementById('pid').value);
        var vArr = [];
        var uArr = [];
        var xyz = [];
        vArr = JSON.parse(visitors);
        uArr = JSON.parse(loggers);
        for (var i = 0; i < vArr.length; i++) {
            for(var j=0; j<uArr.length; j++){
                if ( vArr[i].loggerid==uArr[j].email && parseInt(vArr[i].pid)==pid) {
                    uArr[j].loggerid=vArr[i].loggerid;
                    uArr[j].pid=vArr[i].pid;
                    xyz.push(uArr[j]);
                }
            }
        }
        $scope.applies = xyz;
    }
});
