var myApp = angular.module('myApp', []);

myApp.controller('MainCtrl', function($scope,$rootScope) {
    $scope.visits=[];
    $scope.dispData = function () {

        var visitors = document.getElementById('visitors').value;
        var loggers = document.getElementById('users').value;
        var varr = [];
        var uarr = [];
        var xyz = [];
        varr = JSON.parse(visitors);
        uarr = JSON.parse(loggers);
        for (var i = 0; i < varr.length; i++) {
            for(var j=0;j<uarr.length;j++){
                if (uarr[j] === varr[i]) {
                    xyz.push(uarr[j]);
                    alert(uarr[j]);
                }
            }
        }
        $scope.visits = xyz;
    }
});