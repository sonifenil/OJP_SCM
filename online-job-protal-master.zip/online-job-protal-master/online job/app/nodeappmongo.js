var express = require("express");
var app = express();
var port = 3000;
var path = require('path');

var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine','ejs');
var multer=require('multer');

const MongoClient = require('mongodb').MongoClient;
const assert = require('assert');

// Connection URL
const url = 'mongodb://localhost:27017';

// Database Name
const dbName = 'jobdbs';

str = "string";

var loginid;
app.route('/alogin').post(function (req, res) {
    res.render('alogin');
});

app.route('/ehome').post(function (req, res) {
    res.render('ehome');
});

app.route('/ulogin').post(function (req, res) {
    res.render('ulogin');
});

app.route('/register').post(function (req, res) {
    res.render('register');
});

app.route('/signin').post(function (req, res) {
    MongoClient.connect(url, function (err, client) {

        assert.equal(null, err);
        console.log("Connected successfully to server");
        //console.log(req.body.userid);
        //console.log(req.body.username);
        //uid=req.body.userid;
        const db = client.db(dbName);
        db.collection('ulogin').insert({fname:req.body.fname, lname:req.body.lname,dob:req.body.dob, email:req.body.email,
            pass:req.body.pass, cpass:req.body.cpass,address:req.body.address,mob:req.body.mob,
            gender:req.body.gender},function (err,result) {
            if (err) throw err;

            if (!result)
            {
                db.close;
                res.send("Registration Error");
            }
            else {
                db.close;
                res.render('ulogin');
            }
        });
    });
//    res.send(req.body);
});



app.route('/home').post(function (req, res) {

    MongoClient.connect(url, function (err, client) {

        assert.equal(null, err);
        console.log("Connected successfully to server");
        //console.log(req.body.userid);
        //console.log(req.body.username);
        //uid=req.body.userid;
        const db = client.db(dbName);
        db.collection('login').findOne({username:req.body.username, password:req.body.userpassword},function (err,result) {
            if (err) throw err;
            if (!result)
            {
                db.close;
                res.send("Invalid Login");
            }
            else {
                db.close;
                loginid=req.body.username;
                res.render('home');
            }
        });
    });
});

app.route('/go').post(function (req, res) {

    MongoClient.connect(url, function (err, client) {

        assert.equal(null, err);
        console.log("Connected successfully to server");
        //console.log(req.body.userid);
        //console.log(req.body.username);
        //uid=req.body.userid;
        const db = client.db(dbName);
        db.collection('ulogin').findOne({email:req.body.email, pass:req.body.pass},function (err,result) {
            if (err) throw err;
            if (!result)
            {
                db.close;
                db.collection('alogin').findOne({email:req.body.email, pass:req.body.pass},function (err,result) {
                    if (err) throw err;
                    if (!result)
                    {
                        db.close;
                        res.send("Invalid Login");
                    }
                    else {
                        db.close;
                        var x;
                        db.collection('ulogin').find().toArray(function (err,item){
                            x=item.length;
                        });
                        db.collection('post').find().toArray(function (err,result)
                            {
                                if(err)throw err;
                                if(result){
                                    loginid=req.body.email;
                                    res.render('adminhome',{data:parseInt(result.length),data1:parseInt(x)});
                                }
                            }
                        );
                    }
                });
            }
            else {
                db.close;
                var x;
                db.collection('ulogin').find().toArray(function (err,item){
                    x=item.length;
                });
                db.collection('post').find().toArray(function (err,result)
                    {
                        if(err)throw err;
                        if(result){
                            loginid=req.body.email;
                            res.render('home',{data:parseInt(result.length),data1:parseInt(x)});
                        }
                    }
                );

            }
        });
    });
});

app.route('/customers').post(function (req,res) {
    MongoClient.connect(url, function(err, client) {

        console.log("Connected successfully to server");
        const db = client.db(dbName);
        itemArr=[];
        var col = db.collection('ulogin');
        var i=0;
        var cursor =col.find();
        //noinspection JSDeprecatedSymbols
        cursor.forEach(function(item, err) {
            assert.equal(null, err);
            if(err) throw err;
            if (item != null) {
                itemArr.push(item);
                ++ i;
            }
            else {
                console.log("error");
            }
        },function () {
            db.close;
            res.render('viewcustomers',{data:itemArr,msg:''});
        });
    });
});


app.route('/deleted').post(function (req,res) {
    MongoClient.connect(url,function (err,client) {
        const db=client.db(dbName);
        db.collection('ulogin').remove({email:req.body.email,pass:req.body.pass},function (err, item) {
            if(err) throw err;
            if(item){
                db.close;
               res.send('User Deleted')

            }
        })
    })
});


app.route('/dele').post(function (req,res) {
    MongoClient.connect(url,function (err,client) {
        console.log("success");
        const db=client.db(dbName);
        db.collection('post').remove({pid:req.body.pid});
        res.send('deleted');
    });
});


app.route('/jobadded').post(function (req, res) {
    MongoClient.connect(url, function (err, client) {
        assert.equal(null, err);
        console.log("Connected successfully to server");
        //console.log(req.body.userid);
        //console.log(req.body.username);
        //uid=req.body.userid;
        const db = client.db(dbName);
        db.collection('post').insert({pid:job_id,userid:loginid,cname:req.body.cname,
            size:req.body.size,
            name:req.body.name,
            num:req.body.num,
            jobtitle:req.body.jobtitle,
            location:req.body.location,
            city:req.body.city,
            code:req.body.code,
            types:req.body.types,
            from:req.body.from,
            to:req.body.to,
            pre:req.body.pre,
            numb:req.body.numb,
            summary:req.body.summary,
            duties:req.body.duties,
            skill:req.body.skill,
            benefits:req.body.benefits,
            do:req.body.do,
            sent:req.body.sent,
            ask:req.body.ask,
            experience:req.body.experience,
            exp:req.body.exp,
            education:req.body.education,
            edu:req.body.edu,
            loc:req.body.loc,
            loca:req.body.loca,
            language:req.body.language,
            lang:req.body.lang,
            license:req.body.license,
            jobcategory:req.body.jobcategory,
            lic:req.body.lic}, function (err,result) {
            if (err) throw err;
            if (!result)
            {
                db.close;
                res.send("Registration Error");
            }
            else {
                db.close;
                res.send('Job Updated');
            }
        });
    });
//    res.send(req.body);
});


var alljobs=[];
app.route('/alljobs').post(function (req,res) {
    MongoClient.connect(url, function(err, client) {
        console.log("Connected successfully to server");
        const db = client.db(dbName);
        alljobs=[];
        var col = db.collection('post');
        var i=0;
        var cursor =col.find();
        //noinspection JSDeprecatedSymbols
        cursor.forEach(function(item, err) {
            assert.equal(null, err);
            if(err) throw err;
            if (item != null) {
                alljobs.push(item);
                ++ i;
            }
            else {
                console.log("error");
            }
        },function () {
            db.close;
            res.render('jobs',{data:alljobs});
        });
    });
});

app.route('/').get(function (req, res) {
    res.render('ulogin');
});

app.route('/searchjob').post(function (req,res) {

    MongoClient.connect(url, function(err, client) {
        console.log("Connected successfully to server");
        const db = client.db(dbName);
        alljobs=[];
        var col = db.collection('post');
        var i=0;
        var cursor =col.find();
        //noinspection JSDeprecatedSymbols
        cursor.forEach(function(item, err) {
            assert.equal(null, err);
            if(err) throw err;
            if (item != null && item.pid != 0) {
                alljobs.push(item);
                ++ i;
            }
            else {
                console.log("error");
            }
        },function () {
            db.close;
            console.log(req.body.searchvalue);
            res.render('searchjobs',{data:JSON.stringify(alljobs),data1:req.body.searchvalue});
        });
    });

});

app.route('/postjob').post(function(req,res){
    MongoClient.connect(url, function(err, client) {
        console.log("Connected successfully to server");
        const db = client.db(dbName);
        alljobs=[];
        job_id=1;
        var col = db.collection('post');
        var i=0;
        var cursor =col.find().sort({pid:1}).toArray(function(err, result) {
            if (err) throw err;
            console.log(result);
            job_id=parseInt(result[result.length-1].pid + 1);
            console.log(job_id);
            res.render('postapplication');
        },function () {
            res.render('postapplication');
        });
        //noinspection JSDeprecatedSymbols
    });
});


function getalljobs() {
    MongoClient.connect(url, function(err, client) {
        console.log("Connected successfully to server");
        const db = client.db(dbName);
        alljobs=[];
        var col = db.collection('post');
        var i=0;
        var cursor =col.find();
        //noinspection JSDeprecatedSymbols
        cursor.forEach(function(item, err) {
            assert.equal(null, err);
            if(err) throw err;
            if (item != null) {
                alljobs.push(item);
                ++ i;
            }
            else {
                console.log("error");
            }
        },function () {
            db.close;
        });
    });
}

app.route('/deletepost').post(function (req,res) {
    MongoClient.connect(url,function (err,client) {
        const db =client.db(dbName);
        db.collection('post').remove({pid:parseInt(req.body.pid)},function (err) {
            if(err) throw err;
            getalljobs();
            res.render('adminalljobs',{data:alljobs});
            console.log('deleted')
        });
    })
});

app.route('/adminhome').post(function (req,res) {
    res.render('adminhome');
});


var resu=[];

app.route('/viewjob').post(function (req,res) {
    MongoClient.connect(url, function (err, client) {
        console.log("Connected successfully to server in route viewjob");
        const db = client.db(dbName);
        var col = db.collection('post');
        var i = 0;
        console.log(req.body.pid);

        col.find({pid: parseInt(req.body.pid)}).toArray(function (err, result) {
            if (err) {
                throw err;
            }
            else {
                resu = [];
                for (i = 0; i < result.length; i++) {
                    resu[i] = result[i];
                    console.log(resu[i].name);
                    res.render("viewjob", {data: resu});
                }
            }
        });
    });
});





app.route('/adminviewjob').post(function (req,res) {
    MongoClient.connect(url, function (err, client) {
        console.log("Connected successfully to server in route viewjob");
        const db = client.db(dbName);
        var col = db.collection('post');
        var i = 0;
        console.log(req.body.pid);

        col.find({pid: parseInt(req.body.pid)}).toArray(function (err, result) {
            if (err) {
                throw err;
            }
            else {
                resu = [];
                for (i = 0; i < result.length; i++) {
                    resu[i] = result[i];
                    console.log(resu[i].name);
                    res.render("adminviewjob", {data:JSON.stringify(resu)});
                }
            }
        });
    });
});




var job_id;

app.use('apply',function (req,res,next) {
   next();
});


app.route('/adminalljobs').post(function (req,res) {
    MongoClient.connect(url, function(err, client) {
        console.log("Connected successfully to server");
        const db = client.db(dbName);
        alljobs=[];
        var col = db.collection('post');
        var i=0;
        var cursor =col.find();
        //noinspection JSDeprecatedSymbols
        cursor.forEach(function(item, err) {
            assert.equal(null, err);
            if(err) throw err;
            if (item != null) {
                alljobs.push(item);
                ++ i;
            }
            else {
                console.log("error");
            }
        },function () {
            db.close;
            res.render('adminalljobs',{data:JSON.stringify(alljobs)});
        });
    });
});

app.route('/homes').post(function (req,res) {
   res.render('home');
});


app.listen('3000');

var myjobs=[];

app.route('/myjobs').post(function(req,res){
   MongoClient.connect(url,function (err,client) {
       const db=client.db(dbName);
       db.collection('post').find({userid:loginid}).toArray(function (err, result) {
           if (err) {
               throw err;
           } else {
               myjobs=[];
               for (i = 0; i < result.length; i++) {
                   myjobs[i] = result[i];
                   //   console.log(papers[i]);
               }
               var json = JSON.stringify(myjobs);
               res.render('myjobs', {data: json});
           }
       });

   });
});

app.route('/deletemyjob').post(function (req,res) {
    MongoClient.connect(url,function (err,client) {
        const db=client.db(dbName);
        db.collection('post').remove({pid:parseInt(req.body.pid)},function (err,result) {
            if(err)throw err;
            if(!result){
                res.send('Error While Deleting');
            }
            else{
                res.send('Job Successfully Deleted');
            }
        });
    });
});



app.route('/acceptthisjob').post(function (req,res) {
   MongoClient.connect(url,function (err,client) {
       const db=client.db(dbName);
       db.collection('post').update({pid:parseInt(req.body.pid)},{$set:{jobaccept:'true'}},function (err,item) {
           if(err)throw err;
           if(item){
               res.send('Job Accepted Now Its visible to Clients');
           }
       });
   });
});

app.route('/deletethisjob').post(function (req,res) {
    MongoClient.connect(url,function (err,client) {
        const db=client.db(dbName);
        db.collection('post').remove({pid:parseInt(req.body.jobid)},function (err,result) {
            if(err)throw err;
            if(!result){
                res.send('Error While Deleting');
            }
            else{
                console.log('id:'+parseInt(req.body.jobid));
                res.send('Job Successfully Deleted');
            }
        });
    });
});


app.route('/pendingjobs').post(function (req,res) {
    MongoClient.connect(url,function (err,client) {
        const db=client.db(dbName);
        db.collection('post').find().toArray(function (err, result) {
            if (err) {
                throw err;
            } else {
                myjobs=[];
                for (i = 0; i < result.length; i++) {
                    myjobs[i] = result[i];
                    //   console.log(papers[i]);
                }
            }
            var json = JSON.stringify(myjobs);
            res.render('adminacceptjob', {data: json});
        });

    });
});






app.route('/applyforthis').post(function (req,res) {

    MongoClient.connect(url, function(err, client) {
         console.log("Connected successfully to server  " + req.body.pid);
         const db = client.db(dbName);
         db.collection('visitedjobs').findOne({loggerid:loginid,pid:req.body.pid},function (err,doc) {
             if(doc==null)
             {
                 db.close;
                 db.collection('visitedjobs').insertOne({loggerid:loginid,pid:parseInt(req.body.pid)},
                     function (err,result) {
                         if (err) throw err;
                         if (!result)
                         {
                             db.close;
                             res.send("apply Error");
                         }
                         else {
                             console.log("Connected successfully to server");
                             res.send('Applied Successfully')
                         }
                     }
                 );
             }
             else
             {
                 res.send("already applied");
             }
         });
    });
});


app.route('/visitors').post(function (req,res) {
   MongoClient.connect(url,function (err,client) {
       const db=client.db(dbName);
       var visitors=[];
       var loggers=[];

        db.collection('post').find({userid:loginid,pid:parseInt(req.body.pid)},function (err,doc) {
            if(err) throw err;
            if(!doc){
                console.log("error while retriving login data login with different account");
            }
            else{
                console.log(doc.pid);
                db.collection('ulogin').find().toArray(function (err,item) {
                    if(err)throw err;
                    if(item){
                        for(var j=0;j<item.length;j++){
                            loggers.push(item[j]);
                        }
                        db.close;
                    }
                });
                db.collection('visitedjobs').find().toArray(function (err,item) {
                    if(err)throw err;
                    if(item){
                        for(var j=0;j<item.length;j++){
                            visitors.push(item[j]);
                        }
                        db.close;
                    }
                    console.log(visitors);
                    console.log(loggers);
                    console.log('pid:'+req.body.pid);
                    res.render('jobviews',{data:JSON.stringify(visitors),data1:JSON.stringify(loggers),data2:parseInt(req.body.pid)});
                });
            }
        })
   });
});



var papers=[];



var resume='';


app.route('/resume').post(function (req,res) {
    res.render('upload_resume',{file:resume});
});

app.route('/get_resume').post(function (req,res) {
    upload(req,res,function (err) {
        if(err)
        {
            res.send('Document Files Only and within 1MB ');
        }
        else
        {
            if(req.file == undefined ){
                res.send('error: file not selected');
            }
            else{

                resume=req.file.filename;
                res.render('upload_resume',{file:resume});
            }
        }

    });
});

app.route('/upload_resume').post(function (req, res) {
    MongoClient.connect(url, function (err, client) {

        console.log("Connected successfully to server");
        //console.log(req.body.userid);
        //console.log(req.body.username);
        //uid=req.body.userid;
        const db = client.db(dbName);
        db.collection('ulogin').updateOne({email:loginid},

            { $set: {resume:resume}},function (err,result) {
                if (err) throw err;
                if (!result)
                {
                    db.close;
                    res.send("upload Error");
                }
                else
                {
                    db.close;
                    console.log("uploaded successfully to db");
                    db.collection('post').find({userid:loginid}).toArray(function (err, result) {
                        if (err) {
                            throw err;
                        } else {
                            myjobs=[];
                            for (i = 0; i < result.length; i++) {
                                myjobs[i] = result[i];
                                //   console.log(papers[i]);
                            }
                            var json = JSON.stringify(myjobs);
                            res.render('myjobs', {data: json});
                        }
                    });
                }
            });
    });
});

app.route('/deleteviewer').post(function (req,res) {
    MongoClient.connect(url,function (err,client) {
        const db=client.db(dbName);
        console.log('log id='+req.body.logid);
        console.log('log id='+req.body.pid);
        db.collection('visitedjobs').remove({loggerid:req.body.logid,pid:parseInt(req.body.pid)},function (err,item) {
            if(err)throw err;
            if(!item){
                console.log('error');
                res.send('error wile deleting');
            }
            else{
                res.render('downloadresume');
            }
        })
    });
});



app.route('/downloadresume').post(function (req,res) {
    var address='public/resumes/'+req.body.path;
   res.download(address);
});


const storage = multer.diskStorage({
    destination: './public/resumes/',
    filename:function(req,file,cb){
        var p=file.fieldname + '-' + Date.now() +
            path.extname(file.originalname);
        cb(null,p);
    }
});

const upload =multer({
    storage:storage,
    limits:{fileSize:1000000},
    fileFilter:function (req,file,cb) {
        checkFileType(file,cb);
    }
}).single('resume');



function checkFileType(file,cb) {
    const filetypes=/pdf|doc|docx|rtf/;
    const extname=filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype=filetypes.test(file.mimetype);
    if(mimetype && extname){
        return cb(null,true);
    }
    else
    {
        cb('Error: Documents only')
    }
}






